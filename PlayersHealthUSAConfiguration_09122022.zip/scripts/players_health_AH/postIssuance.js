let constantValues = require("./forms.js");

function getPostIssuanceResult(data)
{
  let policy_application_document_locators = [];
  let dummy_document_locators = [];

  var locator = data.policy.locator;
  var PlayersHealthMasterApplicationTemplateAK = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthMasterApplicationTemplateAK);
  var PlayersHealthMasterApplicationTemplateAL = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthMasterApplicationTemplateAL);
  var PlayersHealthMasterApplicationTemplateAR = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthMasterApplicationTemplateAR);
  var PlayersHealthMasterApplicationTemplateCO = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthMasterApplicationTemplateCO);
  var PlayersHealthMasterApplicationTemplateFL = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthMasterApplicationTemplateFL);
  var PlayersHealthMasterApplicationTemplateGeneric = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthMasterApplicationTemplateGeneric);
  var PlayersHealthMasterApplicationTemplateKS = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthMasterApplicationTemplateKS);
  var PlayersHealthMasterApplicationTemplateKY = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthMasterApplicationTemplateKY);
  var PlayersHealthMasterApplicationTemplateLA = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthMasterApplicationTemplateLA);
  var PlayersHealthMasterApplicationTemplateMD = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthMasterApplicationTemplateMD);
  var PlayersHealthMasterApplicationTemplateNC = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthMasterApplicationTemplateNC);
  var PlayersHealthMasterApplicationTemplateOK = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthMasterApplicationTemplateOK);
  var PlayersHealthMasterApplicationTemplateSD = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthMasterApplicationTemplateSD);
  var PlayersHealthMasterApplicationTemplateTN = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthMasterApplicationTemplateTN);
  var PlayersHealthMasterApplicationTemplateTX = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthMasterApplicationTemplateTX);
  var PlayersHealthMasterApplicationTemplateUT = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthMasterApplicationTemplateUT);
  var PlayersHealthMasterApplicationTemplateVA = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthMasterApplicationTemplateVA);

var PlayersHealthMasterApplicationTemplateVT = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthMasterApplicationTemplateVT);
  var PlayersHealthBlanketAccidentMedicalPolicyAK = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyAK);
  var PlayersHealthBlanketAccidentMedicalPolicyAL = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyAL);
  var PlayersHealthBlanketAccidentMedicalPolicyAR = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyAR);
  var PlayersHealthBlanketAccidentMedicalPolicyAZ = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyAZ);
  var PlayersHealthBlanketAccidentMedicalPolicyCA = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyCA);
  var PlayersHealthBlanketAccidentMedicalPolicyCO = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyCO);
  var PlayersHealthBlanketAccidentMedicalPolicyCT = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyCT);
  var PlayersHealthBlanketAccidentMedicalPolicyDC = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyDC);
  var PlayersHealthBlanketAccidentMedicalPolicyDE = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyDE);
  var PlayersHealthBlanketAccidentMedicalPolicyFL = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyFL);
  var PlayersHealthBlanketAccidentMedicalPolicyGA = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyGA);
  var PlayersHealthBlanketAccidentMedicalPolicyHI = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyHI);
  var PlayersHealthBlanketAccidentMedicalPolicyIA = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyIA);
  var PlayersHealthBlanketAccidentMedicalPolicyIL = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyIL);
  var PlayersHealthBlanketAccidentMedicalPolicyIN = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyIN);
  var PlayersHealthBlanketAccidentMedicalPolicyKS = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyKS);
  var PlayersHealthBlanketAccidentMedicalPolicyKY = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyKY);
  var PlayersHealthBlanketAccidentMedicalPolicyLA = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyLA);
  var PlayersHealthBlanketAccidentMedicalPolicyMA = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyMA);
  var PlayersHealthBlanketAccidentMedicalPolicyMD = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyMD);
  var PlayersHealthBlanketAccidentMedicalPolicyMI = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyMI);
  var PlayersHealthBlanketAccidentMedicalPolicyMN = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyMN);
  var PlayersHealthBlanketAccidentMedicalPolicyMO = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyMO);
  var PlayersHealthBlanketAccidentMedicalPolicyMS = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyMS);
  var PlayersHealthBlanketAccidentMedicalPolicyMT = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyMT);
  var PlayersHealthBlanketAccidentMedicalPolicyNC = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyNC);
  var PlayersHealthBlanketAccidentMedicalPolicyND = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyND);
  var PlayersHealthBlanketAccidentMedicalPolicyNE = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyNE);
  var PlayersHealthBlanketAccidentMedicalPolicyNV = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyNV);
  var PlayersHealthBlanketAccidentMedicalPolicyOH = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyOH);
  var PlayersHealthBlanketAccidentMedicalPolicyOK = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyOK);
  var PlayersHealthBlanketAccidentMedicalPolicyPA = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyPA);
  var PlayersHealthBlanketAccidentMedicalPolicyRI = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyRI);
  var PlayersHealthBlanketAccidentMedicalPolicySC = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicySC);
  var PlayersHealthBlanketAccidentMedicalPolicySD = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicySD);
  var PlayersHealthBlanketAccidentMedicalPolicyTN = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyTN);
  var PlayersHealthBlanketAccidentMedicalPolicyTX = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyTX);
  var PlayersHealthBlanketAccidentMedicalPolicyUT = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyUT);
  var PlayersHealthBlanketAccidentMedicalPolicyVA = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyVA);
  var PlayersHealthBlanketAccidentMedicalPolicyVT = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyVT);

  var PlayersHealthBlanketAccidentMedicalPolicyWI = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyWI);
  var PlayersHealthBlanketAccidentMedicalPolicyWV = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyWV);
  var PlayersHealthBlanketAccidentMedicalPolicyWY = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthBlanketAccidentMedicalPolicyWY);
  var PlayersHealthCertificateTemplateCA = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthCertificateTemplateCA);
  var PlayersHealthCertificateTemplateCT = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthCertificateTemplateCT);
  var PlayersHealthCertificateTemplateDC = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthCertificateTemplateDC);
  var PlayersHealthCertificateTemplateFL = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthCertificateTemplateFL);
  var PlayersHealthCertificateTemplateIN = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthCertificateTemplateIN);
  var PlayersHealthCertificateTemplateKS = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthCertificateTemplateKS);
  var PlayersHealthCertificateTemplateLA = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthCertificateTemplateLA);
  var PlayersHealthCertificateTemplateMO = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthCertificateTemplateMO);
  var PlayersHealthCertificateTemplateNC = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthCertificateTemplateNC);
  var PlayersHealthCertificateTemplateVA = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthCertificateTemplateVA);
  var PlayersHealthOutlineOfCoverageTemplateUT = socotraApi.getAuxData(locator, constantValues.formNameConstants.PlayersHealthOutlineOfCoverageTemplateUT);
  var SiriusAmericaNoticeofPrivacyRights = socotraApi.getAuxData(locator, constantValues.formNameConstants.SiriusAmericaNoticeofPrivacyRights);
  var OFACNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.OFACNotice);
  var AKGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.AKGuarantyNotice);
  var ARGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.ARGuarantyNotice);
  var CAGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.CAGuarantyNotice);
  var COGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.COGuarantyNotice);
  var DCGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.DCGuarantyNotice);
  var HIGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.HIGuarantyNotice);
  var IAGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.IAGuarantyNotice);
  var IDGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.IDGuarantyNotice);
  var ILGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.ILGuarantyNotice);
  var INGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.INGuarantyNotice);
  var KSGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.KSGuarantyNotice);
  var LAGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.LAGuarantyNotice);
  var MDGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.MDGuarantyNotice);
  var MIGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.MIGuarantyNotice);
  var MNGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.MNGuarantyNotice);
  var MOGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.MOGuarantyNotice);
  var MSGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.MSGuarantyNotice);
  var MTGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.MTGuarantyNotice);
  var NCGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.NCGuarantyNotice);
  var NDGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.NDGuarantyNotice);
  var NHGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.NHGuarantyNotice);
  var NJGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.NJGuarantyNotice);
  var NMGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.NMGuarantyNotice);
  var NVGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.NVGuarantyNotice);
  var OKGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.OKGuarantyNotice);

  var PAGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.PAGuarantyNotice);
  var RIGuarantyNotice  = socotraApi.getAuxData(locator, constantValues.formNameConstants.RIGuarantyNotice );
  var SDGuarantyNotice  = socotraApi.getAuxData(locator, constantValues.formNameConstants.SDGuarantyNotice );
  var TNGuarantyNotice  = socotraApi.getAuxData(locator, constantValues.formNameConstants.TNGuarantyNotice );
  var TXGuarantyNoticeSpanish  = socotraApi.getAuxData(locator, constantValues.formNameConstants.TXGuarantyNoticeSpanish );
  var TXGuarantyNotice = socotraApi.getAuxData(locator, constantValues.formNameConstants.TXGuarantyNotice);
  var UTGuarantyNotice  = socotraApi.getAuxData(locator, constantValues.formNameConstants.UTGuarantyNotice );
  var VAGuarantyNotice  = socotraApi.getAuxData(locator, constantValues.formNameConstants.VAGuarantyNotice );
  var WAGuarantyNoticeBrochure  = socotraApi.getAuxData(locator, constantValues.formNameConstants.WAGuarantyNoticeBrochure );
  var WVGuarantyNotice  = socotraApi.getAuxData(locator, constantValues.formNameConstants.WVGuarantyNotice );
  var WYGuarantyNotice  = socotraApi.getAuxData(locator, constantValues.formNameConstants.WYGuarantyNotice );
  var BAPCOMPLAINTNOTICEWI  = socotraApi.getAuxData(locator, constantValues.formNameConstants.BAPCOMPLAINTNOTICEWI );
  var NCFiduciaryNotice  = socotraApi.getAuxData(locator, constantValues.formNameConstants.NCFiduciaryNotice );

  for (let document of data.documents)
  {
    if (PlayersHealthMasterApplicationTemplateAK == "Yes")
    {
      if (document.fileName == "PlayersHealthMasterApplicationTemplateAK.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }
  
  for (let document of data.documents)
  {
    if (PlayersHealthMasterApplicationTemplateAL == "Yes")
    {
      if (document.fileName == "PlayersHealthMasterApplicationTemplateAL.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }
  for (let document of data.documents)
  {
    if (PlayersHealthMasterApplicationTemplateAR == "Yes")
    {
      if (document.fileName == "PlayersHealthMasterApplicationTemplateAR.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }
  for (let document of data.documents)
  {
    if (PlayersHealthMasterApplicationTemplateCO == "Yes")
    {
      if (document.fileName == "PlayersHealthMasterApplicationTemplateCO.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }
  for (let document of data.documents)
  {
    if (PlayersHealthMasterApplicationTemplateFL == "Yes")
    {
      if (document.fileName == "PlayersHealthMasterApplicationTemplateFL.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  } 
  
  for (let document of data.documents)
  {
    if (PlayersHealthMasterApplicationTemplateGeneric == "Yes")
    {
      if (document.fileName == "PlayersHealthMasterApplicationTemplateGenericAZ.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }
 
  for (let document of data.documents)
  {
    if (PlayersHealthMasterApplicationTemplateKS == "Yes")
    {
      if (document.fileName == "PlayersHealthMasterApplicationTemplateKS.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }
  for (let document of data.documents)
  {
    if (PlayersHealthMasterApplicationTemplateKY == "Yes")
    {
      if (document.fileName == "PlayersHealthMasterApplicationTemplateKY.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }
  for (let document of data.documents)
  {
    if (PlayersHealthMasterApplicationTemplateLA == "Yes")
    {
      if (document.fileName == "PlayersHealthMasterApplicationTemplateLA.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }
  for (let document of data.documents)
  {
    if (PlayersHealthMasterApplicationTemplateMD == "Yes")
    {
      if (document.fileName == "PlayersHealthMasterApplicationTemplateMD.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }
  for (let document of data.documents)
  {
    if (PlayersHealthMasterApplicationTemplateNC == "Yes")
    {
      if (document.fileName == "PlayersHealthMasterApplicationTemplateNC.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }
  for (let document of data.documents)
  {
    if (PlayersHealthMasterApplicationTemplateOK == "Yes")
    {
      if (document.fileName == "PlayersHealthMasterApplicationTemplateOK.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }
  for (let document of data.documents)
  {
    if (PlayersHealthMasterApplicationTemplateSD == "Yes")
    {
      if (document.fileName == "PlayersHealthMasterApplicationTemplateSD.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }
  for (let document of data.documents)
  {
    if (PlayersHealthMasterApplicationTemplateTN == "Yes")
    {
      if (document.fileName == "PlayersHealthMasterApplicationTemplateTN.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }
  for (let document of data.documents)
  {
    if (PlayersHealthMasterApplicationTemplateTX == "Yes")
    {
      if (document.fileName == "PlayersHealthMasterApplicationTemplateTX.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }
  for (let document of data.documents)
  {
    if (PlayersHealthMasterApplicationTemplateUT == "Yes")
    {
      if (document.fileName == "PlayersHealthMasterApplicationTemplateUT.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }
  for (let document of data.documents)
  {
    if (PlayersHealthMasterApplicationTemplateVA == "Yes")
    {
      if (document.fileName == "PlayersHealthMasterApplicationTemplateVA.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

for (let document of data.documents)
{
  if (PlayersHealthMasterApplicationTemplateVT == "Yes")
  {
    if (document.fileName == "PlayersHealthMasterApplicationTemplateVT.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}

for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyAK == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyAK.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyAL == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyAL.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyAR == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyAR.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyAZ == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyAZ.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyCA == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyCA.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyCO == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyCO.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyCT == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyCT.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyDC == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyDC.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyDE == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyDE.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyFL == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyFL.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyGA == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyGA.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyHI == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyHI.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyIA == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyIA.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyIL == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyIL.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyIN == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyIN.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyKS == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyKS.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyKY == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyKY.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyLA == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyLA.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyMA == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyMA.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyMD == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyMD.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyMI == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyMI.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
} 
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyMN == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyMN.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyMO == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyMO.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyMS == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyMS.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyMT == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyMT.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyNC == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyNC.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyND == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyND.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyNE == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyNE.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyNV == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyNV.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyOH == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyOH.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyOK == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyOK.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyPA == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyPA.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyRI == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyRI.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicySC == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicySC.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicySD == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicySD.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyTN == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyTN.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyTX == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyTX.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyUT == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyUT.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyVA == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyVA.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
for (let document of data.documents)
{
  if (PlayersHealthBlanketAccidentMedicalPolicyVT == "Yes")
  {
    if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyVT.pdf")
    {
      policy_application_document_locators.push(document.locator);
    }
  }
  else
  {
    dummy_document_locators.push(document.locator);
  }
}
  
  for (let document of data.documents)
  {
    if (PlayersHealthBlanketAccidentMedicalPolicyWI == "Yes")
    {
      if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyWI.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (PlayersHealthBlanketAccidentMedicalPolicyWV == "Yes")
    {
      if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyWV.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (PlayersHealthBlanketAccidentMedicalPolicyWY == "Yes")
    {
      if (document.fileName == "PlayersHealthBlanketAccidentMedicalPolicyWY.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (PlayersHealthCertificateTemplateCA == "Yes")
    {
      if (document.fileName == "PlayersHealthCertificateTemplateCA.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (PlayersHealthCertificateTemplateCT == "Yes")
    {
      if (document.fileName == "PlayersHealthCertificateTemplateCT.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (PlayersHealthCertificateTemplateDC == "Yes")
    {
      if (document.fileName == "PlayersHealthCertificateTemplateDC.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (PlayersHealthCertificateTemplateFL == "Yes")
    {
      if (document.fileName == "PlayersHealthCertificateTemplateFL.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (PlayersHealthCertificateTemplateIN == "Yes")
    {
      if (document.fileName == "PlayersHealthCertificateTemplateIN.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (PlayersHealthCertificateTemplateKS == "Yes")
    {
      if (document.fileName == "PlayersHealthCertificateTemplateKS.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (PlayersHealthCertificateTemplateLA == "Yes")
    {
      if (document.fileName == "PlayersHealthCertificateTemplateLA.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (PlayersHealthCertificateTemplateMO == "Yes")
    {
      if (document.fileName == "PlayersHealthCertificateTemplateMO.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (PlayersHealthCertificateTemplateNC == "Yes")
    {
      if (document.fileName == "PlayersHealthCertificateTemplateNC.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (PlayersHealthCertificateTemplateVA == "Yes")
    {
      if (document.fileName == "PlayersHealthCertificateTemplateVA.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (PlayersHealthOutlineOfCoverageTemplateUT == "Yes")
    {
      if (document.fileName == "PlayersHealthOutlineOfCoverageTemplateUT.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (SiriusAmericaNoticeofPrivacyRights == "Yes")
    {
      if (document.fileName == "SiriusAmericaNoticeofPrivacyRights.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (OFACNotice == "Yes")
    {
      if (document.fileName == "OFACNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }
  
  for (let document of data.documents)
  {
    if (AKGuarantyNotice == "Yes")
    {
      if (document.fileName == "AKGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (ARGuarantyNotice == "Yes")
    {
      if (document.fileName == "ARGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (CAGuarantyNotice == "Yes")
    {
      if (document.fileName == "CAGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (COGuarantyNotice == "Yes")
    {
      if (document.fileName == "COGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (DCGuarantyNotice == "Yes")
    {
      if (document.fileName == "DCGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (HIGuarantyNotice == "Yes")
    {
      if (document.fileName == "HIGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (IAGuarantyNotice == "Yes")
    {
      if (document.fileName == "IAGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (IDGuarantyNotice == "Yes")
    {
      if (document.fileName == "IDGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (ILGuarantyNotice == "Yes")
    {
      if (document.fileName == "ILGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (INGuarantyNotice == "Yes")
    {
      if (document.fileName == "INGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (KSGuarantyNotice == "Yes")
    {
      if (document.fileName == "KSGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (LAGuarantyNotice == "Yes")
    {
      if (document.fileName == "LAGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (MDGuarantyNotice == "Yes")
    {
      if (document.fileName == "MDGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (MIGuarantyNotice == "Yes")
    {
      if (document.fileName == "MIGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (MNGuarantyNotice == "Yes")
    {
      if (document.fileName == "MNGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (MOGuarantyNotice == "Yes")
    {
      if (document.fileName == "MOGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (MSGuarantyNotice == "Yes")
    {
      if (document.fileName == "MSGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (MTGuarantyNotice == "Yes")
    {
      if (document.fileName == "MTGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (NCGuarantyNotice == "Yes")
    {
      if (document.fileName == "NCGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (NDGuarantyNotice == "Yes")
    {
      if (document.fileName == "NDGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (NHGuarantyNotice == "Yes")
    {
      if (document.fileName == "NHGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (NJGuarantyNotice == "Yes")
    {
      if (document.fileName == "NJGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (NMGuarantyNotice == "Yes")
    {
      if (document.fileName == "NMGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (NVGuarantyNotice == "Yes")
    {
      if (document.fileName == "NVGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (OKGuarantyNotice == "Yes")
    {
      if (document.fileName == "OKGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (PAGuarantyNotice == "Yes")
    {
      if (document.fileName == "PAGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }
  for (let document of data.documents)
  {
    if (RIGuarantyNotice == "Yes")
    {
      if (document.fileName == "RIGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (SDGuarantyNotice == "Yes")
    {
      if (document.fileName == "SDGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (TNGuarantyNotice == "Yes")
    {
      if (document.fileName == "TNGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }


  for (let document of data.documents)
  {
    if (TXGuarantyNoticeSpanish == "Yes")
    {
      if (document.fileName == "TXGuarantyNoticeSpanish.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  
 
  for (let document of data.documents)
  {
    if (TXGuarantyNotice== "Yes")
    {
      if (document.fileName == "TXGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }
  

  for (let document of data.documents)
  {
    if (UTGuarantyNotice== "Yes")
    {
      if (document.fileName == "UTGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }


  for (let document of data.documents)
  {
    if (VAGuarantyNotice== "Yes")
    {
      if (document.fileName == "VAGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (WAGuarantyNoticeBrochure == "Yes")
    {
      if (document.fileName == "WAGuarantyNoticeBrochure.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }



  for (let document of data.documents)
  {
    if (WVGuarantyNotice == "Yes")
    {
      if (document.fileName == "WVGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }
  for (let document of data.documents)
  {
    if (WYGuarantyNotice == "Yes")
    {
      if (document.fileName == "WYGuarantyNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for(let document of data.documents)
  {
    if (BAPCOMPLAINTNOTICEWI == "Yes")
    {
      if (document.fileName == "BAPCOMPLAINTNOTICEWI.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }

  for (let document of data.documents)
  {
    if (NCFiduciaryNotice == "Yes")
    {
      if (document.fileName == "NCFiduciaryNotice.pdf")
      {
        policy_application_document_locators.push(document.locator);
      }
    }
    else
    {
      dummy_document_locators.push(document.locator);
    }
  }


























  if (data.operation == "cancellation" || 
  data.operation == "endorsement" || 
  data.operation == "renewal" || 
  data.operation == "reinstatement")
{
  return { documentConsolidations:[]}
}
else
{
  return {
    documentConsolidations: [
    {
      displayName: "Policy Document",
      documentLocators: policy_application_document_locators,
      fileName: "policy_document.pdf",
      deleteSourceDocuments: true
    },
   ]
  }
}


}
exports.getPostIssuanceResult = getPostIssuanceResult;



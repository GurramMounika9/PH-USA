let moment = require("../players_health_AH/prorater/moment-with-locales.js");
let constantValues = require("../players_health_AH/prorater/constants.js");

function getProrationResult(data) {
  return {
    items: data.items.map(item => prorateItem(data, item))
  };
}

function prorateItem(data, item) {
  let fraction = getLinearFraction(data, item);  
  let amount = round2(fraction * parseFloat(item.amount));
  return {
    id: item.id,
    proratedAmount: amount,
    holdbackAmount: 0
  };
}

function getDaysBetweenTimestamp(end_timestamp, start_timestamp) {
  var start_time = new Date(+start_timestamp);
  start_time = moment(start_time).format(constantValues.dateFormat.year_month_date);
  var end_time = new Date(+end_timestamp);
  end_time = moment(end_time).format(constantValues.dateFormat.year_month_date);
  let days_diff = moment(new Date(end_time)).diff(new Date(start_time), 'days', true);
  return Math.round(days_diff);
}

function getLinearFraction(data, item) {
  return Math.max(0,
    Math.min(1.0,
      (getDaysBetweenTimestamp(parseInt(data.segmentSplitTimestamp), parseInt(item.segmentStartTimestamp))) /
      (getDaysBetweenTimestamp(parseInt(item.segmentEndTimestamp), parseInt(item.segmentStartTimestamp)))));
}

function round2(num) {
  return Math.round(num * 100) / 100.0;
}

exports.getProrationResult = getProrationResult;
let moment = require("../players_health/prorater/moment-with-locales.js");
let constantValues = require("../players_health/prorater/constants.js");

function getProrationResult(data) {
  return {
    items: data.items.map(item => prorateItem(data, item))
  };
}
function prorateItem(data, item) {
  socotraApi.setAuxData(data.policy.locator, "prorater", JSON.stringify(data), "hidden");
 
  let fraction = getLinearFraction(data, item);
  
  let holdbackAmount;
  console.log("🚀 ~ file: prorater.js ~ line 12 ~ prorateItem ~ fraction", fraction)
  let amount;
  let minPremium;
  let FullyEarnedPerils = ["Personal Advertising Injury", "Liquor Liability", "Products and Completed Operations", "Damage to Premises Rented", "Employee Benefits", "Additional Insured Coverage", "Birthday Parties", "Inflatables", "Batting Cages", "Traverse Or Climbing Walls", "SoftPlay", "Swimming Pools", "ZipLine Ropes Silks Trapees", "Booster Clubs", "Camp Tackle Football", "Retail Store", "Stop Gap Coverage", "Crisis Response", "Tanning Beds"];
  let minPremiumPerils = ["Sexual Abuse and Molestation", "Hired Or Non-Owned Auto", "Professional Liability", "Errors Omissions"];
  if (data.operation == constantValues.operationConstants.endorsement) {
    if (FullyEarnedPerils.indexOf(item.perilName) > -1) {
      amount = parseFloat(item.amount);
      console.log("🚀 ~ file: prorater.js ~ line 23 ~ prorateItem ~ amount", amount)

    }
    else {
      amount = round2(fraction * parseFloat(item.amount));
      console.log("🚀 ~ file: prorater.js ~ line 28 ~ prorateItem ~ amount", amount)

    }
  }
  else {
    amount = round2(fraction * parseFloat(item.amount));
    console.log("🚀 ~ file: prorater.js ~ line 34 ~ prorateItem ~ amount", amount)
  }

  if (data.operation == constantValues.operationConstants.cancellation) {
    holdbackAmount = getholdbackAmount(fraction, data, item ,FullyEarnedPerils);
    console.log("🚀 ~ file: prorater.js ~ line 51 ~ prorateItem ~ holdbackAmount", holdbackAmount)
  }
  else {
    holdbackAmount = 0;
  }
  return {
    id: item.id,
    proratedAmount: amount,
    holdbackAmount: holdbackAmount
  };
}
function getholdbackAmount(fraction, data, item ,FullyEarnedPerils) {
  let holdbackAmount = constantValues.numberConstants.zero;
  let minPremium = constantValues.numberConstants.zero;
  let minPremiumPerils = ["Sexual Abuse and Molestation", "Hired Or Non-Owned Auto", "Professional Liability", "Errors Omissions"];


  if (minPremiumPerils.indexOf(item.perilName) > -1) {
    if (item.perilName == "Hired Or Non-Owned Auto") {
      minPremium = constantValues.numberConstants.five_hundred;
    }
    else if (item.perilName == "Professional Liability") {
      minPremium = constantValues.numberConstants.two_fifty;
    }
    else if (item.perilName == "Errors Omissions") {
      minPremium = constantValues.numberConstants.two_fifty;
    }
    else if (item.perilName == "Sexual Abuse and Molestation") {
      let sexualLimit = item.fieldValues.sexual_abuse_limit;
      console.log("🚀 ~ file: prorater.js ~ line 520 ~ getholdbackAmount ~ sexualLimit", sexualLimit)
      if (sexualLimit == "$50,000/$100,000") {
        minPremium = constantValues.numberConstants.hundred;
      }
      else if (sexualLimit == "$100,000/$300,000") {
        minPremium = constantValues.numberConstants.one_two_five;
      }
      else if (sexualLimit == "$500,000/$500,000") {
        minPremium = constantValues.numberConstants.one_fifty;
      }
      else if (sexualLimit == "$1,000,000/$1,000,000") {
        minPremium = constantValues.numberConstants.two_fifty;
      }
      else if (sexualLimit == "$1,000,000/$2,000,000") {
        minPremium = constantValues.numberConstants.three_fifty;
      }
    }
    holdbackAmount = Math.max(parseFloat(item.amount) * fraction, minPremium);
    console.log("🚀 ~ file: prorater.js ~ line 2 ~ getholdbackAmount ~ holdbackAmount", holdbackAmount)
    console.log("🚀 ~ file: prorater.js ~ line 4 ~ getholdbackAmount ~ minPremium", minPremium)
    if (holdbackAmount == minPremium) {
      holdbackAmount = minPremium - (parseFloat(item.amount) * fraction);
      console.log("🚀 ~ file: prorater.js ~ line 65 ~ getholdbackAmount ~ holdbackAmount", holdbackAmount)
    }
    else {
      holdbackAmount = 0;
      console.log("🚀 ~ file: prorater.js ~ line 75 ~ getholdbackAmount ~ holdbackAmount", holdbackAmount)
    }

  }
  else if(FullyEarnedPerils.indexOf(item.perilName) > -1)
  {
    holdbackAmount = parseFloat(item.amount) - (parseFloat(item.amount) * fraction);
    console.log("🚀 ~ file: prorater.js ~ line 112 ~ getholdbackAmount ~ holdbackAmount", holdbackAmount)
  }
  else {
    holdbackAmount = 0;
  }
  return holdbackAmount;
}

function getDaysBetweenTimestamp(end_timestamp, start_timestamp) {
  var start_time = new Date(+start_timestamp);
  start_time = moment(start_time).format(constantValues.dateFormat.year_month_date);
  var end_time = new Date(+end_timestamp);
  end_time = moment(end_time).format(constantValues.dateFormat.year_month_date);
  let days_diff = moment(new Date(end_time)).diff(new Date(start_time), 'days', true);
  return Math.round(days_diff);
}

function getLinearFraction(data, item) {
  return Math.max(0,
    Math.min(1.0,
      (getDaysBetweenTimestamp(parseInt(data.segmentSplitTimestamp), parseInt(item.segmentStartTimestamp))) /
      (getDaysBetweenTimestamp(parseInt(item.segmentEndTimestamp), parseInt(item.segmentStartTimestamp)))));
}

function round2(num) {
  return Math.round(num * 100) / 100.0;
}
exports.getProrationResult = getProrationResult;
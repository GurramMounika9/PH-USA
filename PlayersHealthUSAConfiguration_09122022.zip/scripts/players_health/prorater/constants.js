let operationConstants = {
   new_business : "newBusiness",
   endorsement : "endorsement",
   fee_assessment : "feeAssessment",
   renewal: "renewal",
   cancellation :"cancellation",
   reinstatement : "reinstatement"
}
const modificationConstants = {
   new_business:"modification.policy.create",
   policy_endorsement : "policy_endorsement",
   renew:"modification.policy.renew"
};
let paymentScheduleConstants = {
   mortgage: "Mortgagee Bill",
   full_pay : "Full Pay",
   quarterly : "Quarterly",
   monthly : "Monthly"
}

let termConstants = {
   semiannually : "semiannually",
   month : "month",
   exception : "Payment schedule is not implemented!",
   thirty_days : "30day",
   ninty_days : "90day"
}

let numberConstants = {
   thousand : 1000,
   four: 4,
   twelve: 12,
   zero: 0,
   five_hundred:500,
   two_fifty:250,
   hundred:100,
   one_fifty:150,
   three_fifty:350,
   one_two_five:125
}

let feeConstants = {
   fee: "fee",
   tax: "tax",
   installment_fee_cards_ach:"installment_fee_cards_ach",
   installment_fee_other:"installment_fee_other",
   reinstatement_fee:"reinstatement_fee"
}


let cancellationTypeConstants = {
   insured_cancellation:"Manual Cancellation - Insured Request",
   company_cancellation :"Manual Cancellation - Company Request"
}

const dateFormat = {
   year_month_date: "YYYY-MM-DD"
};

let paymentType = {
   credit_card : "Credit Card",
   ach : "ACH",
   mortagee_bill : "Mortagee Bill"
};

exports.paymentType = paymentType;
exports.modificationConstants = modificationConstants;
exports.dateFormat = dateFormat;
exports.numberConstants = numberConstants;
exports.feeConstants = feeConstants;
exports.operationConstants = operationConstants;
exports.paymentScheduleConstants = paymentScheduleConstants;
exports.termConstants = termConstants;
exports.cancellationTypeConstants = cancellationTypeConstants;